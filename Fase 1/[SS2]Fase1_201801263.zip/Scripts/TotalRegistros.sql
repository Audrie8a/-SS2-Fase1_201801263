use seminariodosColumnar201801263;
use seminariodos201801263;

Select count (*) from Proveedor; --115
SELECT * FROM Proveedor;

Select count (*) from Producto; --250
SELECT * FROM Producto;

Select count (*) from Sucursal; --120
SELECT * FROM Sucursal;

Select count (*) from Cliente; --299
SELECT * FROM Cliente;

Select count (*) from Vendedor; --69
SELECT * FROM Vendedor;

Select count (*) from Tiempo;	--366
SELECT * FROM Tiempo; 

Select count (*) from Compra; --113
SELECT * FROM Compra;

Select count (*) from Venta;  --347
SELECT * FROM Venta;
